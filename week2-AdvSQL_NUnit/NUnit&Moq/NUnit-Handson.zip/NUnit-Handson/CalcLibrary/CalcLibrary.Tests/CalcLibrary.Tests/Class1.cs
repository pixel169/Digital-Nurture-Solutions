﻿using System;

namespace CalcLibrary.Tests
{
    public class Class1
    {

    }
}
